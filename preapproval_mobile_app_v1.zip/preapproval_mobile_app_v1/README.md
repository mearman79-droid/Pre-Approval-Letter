# FCM Pre-Approval Letter Generator - Mobile App V1

This is a phone-friendly web app that generates a customized Word document from the updated FCM pre-approval letter template.

## Use on your phone

1. Upload this folder to a simple host such as Netlify, Vercel, GitHub Pages, or your company intranet.
2. Open the hosted URL on your iPhone in Safari.
3. Tap Share -> Add to Home Screen.
4. Open it like a normal app, enter client/property details, and tap Generate Word Document.

## Files

- `index.html` - the app
- `preapproval_template.docx` - the Word template used by the app
- `manifest.json` and `sw.js` - allow home screen installation behavior

## Notes

This version generates Word documents in the browser. It does not store client data on a server.
